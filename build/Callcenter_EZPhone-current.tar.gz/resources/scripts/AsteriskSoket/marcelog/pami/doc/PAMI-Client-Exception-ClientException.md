PAMI\Client\Exception\ClientException
===============

Connection/Protocol exception.

PHP Version 5


* Class name: ClientException
* Namespace: PAMI\Client\Exception
* Parent class: [PAMI\Exception\PAMIException](PAMI-Exception-PAMIException.md)








