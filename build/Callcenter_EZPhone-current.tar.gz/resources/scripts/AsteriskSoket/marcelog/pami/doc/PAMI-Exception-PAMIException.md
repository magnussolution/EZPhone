PAMI\Exception\PAMIException
===============

PAMI family of exceptions.

PHP Version 5


* Class name: PAMIException
* Namespace: PAMI\Exception
* Parent class: Exception








