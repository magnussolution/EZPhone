###########
EZPhone 1
###########


Linux Centos 7


### Installation
```
cd /usr/src/
yum -y install wget
wget https://raw.githubusercontent.com/magnussolution/EZPhone/master/script/install.sh
chmod +x install.sh
./install.sh

```


## Version

Estamos na versao 1.x.x 

## Autores

* **Adilson Magnus** - *Initial work* - [MagnusSolution](https://magnussolution.com)


## License

This project is licensed under the GPL3 License

